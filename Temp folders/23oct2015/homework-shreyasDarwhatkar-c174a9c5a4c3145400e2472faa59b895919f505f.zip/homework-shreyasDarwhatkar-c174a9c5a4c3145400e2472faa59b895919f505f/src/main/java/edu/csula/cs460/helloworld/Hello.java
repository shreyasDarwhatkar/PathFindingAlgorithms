package edu.csula.cs460.helloworld;

abstract class Hello {
    public abstract String saySomething(String message);
}
