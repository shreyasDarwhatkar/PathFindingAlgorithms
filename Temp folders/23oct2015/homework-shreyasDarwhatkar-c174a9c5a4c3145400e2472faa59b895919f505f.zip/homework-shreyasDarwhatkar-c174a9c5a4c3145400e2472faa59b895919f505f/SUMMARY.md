# Summary

* [Readme](README.md)
* [Syllabus](Syllabus.md)
* [Lesson 1 - Knowledge Representation](documents/notes/knowledge-representation.md)
   * [homework1](documents/homeworks/homework1.md)

