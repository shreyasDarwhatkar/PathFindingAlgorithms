# Objectives

* Recursion Review
* BFS (Breadth First Search)
* DFS (Depth First Search)

# Metrics/Desired Outcomes

* Understanding BFS/DFS
* Able to implement BFS/DFS

# Recursion Review

* Base case
* Induction

# BFS

# DFS
